    function blockBonus11() {document.getElementById('front-cr').classList.add('flipped');}
    function delblock11(){document.getElementById('front-cr').style.display = "none";document.getElementById('back-cr').style.display = "block";document.getElementById('front-cr').classList.remove('flipped');}
    function blockBonus12(){document.getElementById('back-cr').classList.add('flipped');}
    function delblock12(){document.getElementById('front-cr').style.display = "block";document.getElementById('back-cr').style.display = "none";document.getElementById('back-cr').classList.remove('flipped');}
    function blockBonus21() {document.getElementById('front-cr-1').classList.add('flipped');}
    function delblock21(){document.getElementById('front-cr-1').style.display = "none";document.getElementById('back-cr-1').style.display = "block";document.getElementById('front-cr-1').classList.remove('flipped');}
    function blockBonus22(){document.getElementById('back-cr-1').classList.add('flipped');}
    function delblock22(){document.getElementById('front-cr-1').style.display = "block";document.getElementById('back-cr-1').style.display = "none";document.getElementById('back-cr-1').classList.remove('flipped');}
    function blockBonus31() {document.getElementById('front-cr-2').classList.add('flipped');}
    function delblock31(){document.getElementById('front-cr-2').style.display = "none";document.getElementById('back-cr-2').style.display = "block";document.getElementById('front-cr-2').classList.remove('flipped');}
    function blockBonus32(){document.getElementById('back-cr-2').classList.add('flipped');}
    function delblock32(){document.getElementById('front-cr-2').style.display = "block";document.getElementById('back-cr-2').style.display = "none";document.getElementById('back-cr-2').classList.remove('flipped');}
    function blockBonus41() {document.getElementById('front-cr-3').classList.add('flipped');}
    function delblock41(){document.getElementById('front-cr-3').style.display = "none";document.getElementById('back-cr-3').style.display = "block";document.getElementById('front-cr-3').classList.remove('flipped');}
    function blockBonus42(){document.getElementById('back-cr-3').classList.add('flipped');}
    function delblock42(){document.getElementById('front-cr-3').style.display = "block";document.getElementById('back-cr-3').style.display = "none";document.getElementById('back-cr-3').classList.remove('flipped');}
    function blockBonus51() {document.getElementById('front-cr-4').classList.add('flipped');}
    function delblock51(){document.getElementById('front-cr-4').style.display = "none";document.getElementById('back-cr-4').style.display = "block";document.getElementById('front-cr-4').classList.remove('flipped');}
    function blockBonus52(){document.getElementById('back-cr-4').classList.add('flipped');}
    function delblock52(){document.getElementById('front-cr-4').style.display = "block";document.getElementById('back-cr-4').style.display = "none";document.getElementById('back-cr-4').classList.remove('flipped');}
    function blockBonus61() {document.getElementById('front-cr-5').classList.add('flipped');}
    function delblock61(){document.getElementById('front-cr-5').style.display = "none";document.getElementById('back-cr-5').style.display = "block";document.getElementById('front-cr-5').classList.remove('flipped');}
    function blockBonus62(){document.getElementById('back-cr-5').classList.add('flipped');}
    function delblock62(){document.getElementById('front-cr-5').style.display = "block";document.getElementById('back-cr-5').style.display = "none";document.getElementById('back-cr-5').classList.remove('flipped');}
    function blockBonus71() {document.getElementById('front-cr-6').classList.add('flipped');}
    function delblock71(){document.getElementById('front-cr-6').style.display = "none";document.getElementById('back-cr-6').style.display = "block";document.getElementById('front-cr-6').classList.remove('flipped');}
    function blockBonus72(){document.getElementById('back-cr-6').classList.add('flipped');}
    function delblock72(){document.getElementById('front-cr-6').style.display = "block";document.getElementById('back-cr-6').style.display = "none";document.getElementById('back-cr-6').classList.remove('flipped');}
    function blockBonus81() {document.getElementById('front-cr-7').classList.add('flipped');}
    function delblock81(){document.getElementById('front-cr-7').style.display = "none";document.getElementById('back-cr-7').style.display = "block";document.getElementById('front-cr-7').classList.remove('flipped');}
    function blockBonus82(){document.getElementById('back-cr-7').classList.add('flipped');}
    function delblock82(){document.getElementById('front-cr-7').style.display = "block";document.getElementById('back-cr-7').style.display = "none";document.getElementById('back-cr-7').classList.remove('flipped');}
    function blockBonus91() {document.getElementById('front-cr-8').classList.add('flipped');}
    function delblock91(){document.getElementById('front-cr-8').style.display = "none";document.getElementById('back-cr-8').style.display = "block";document.getElementById('front-cr-8').classList.remove('flipped');}
    function blockBonus92(){document.getElementById('back-cr-8').classList.add('flipped');}
    function delblock92(){document.getElementById('front-cr-8').style.display = "block";document.getElementById('back-cr-8').style.display = "none";document.getElementById('back-cr-8').classList.remove('flipped');}
